extern void executeOpen(const char *noun);
extern void executeClose(const char *noun);
extern void executeLock(const char *noun);
extern void executeUnlock(const char *noun);
