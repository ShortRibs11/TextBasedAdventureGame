
char *combineStrings(const char *str1, const char *str2, int size);
