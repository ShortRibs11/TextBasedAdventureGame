extern int executeTurnOn(void);
extern int executeTurnOff(void);
extern int executeLight(void);
extern int executeExtinguish(void);
