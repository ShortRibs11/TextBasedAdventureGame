
extern int isWorldUpdateNeeded(void);
extern void triggerWorldUpdate(void);
extern void worldUpdate(void);
