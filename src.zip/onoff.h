extern int executeTurnOn(void);
extern int executeTurnOff(void);
