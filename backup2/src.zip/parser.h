extern int parseAndExecute(char *input);
