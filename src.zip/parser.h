extern int parseAndExecute(const char *input);
