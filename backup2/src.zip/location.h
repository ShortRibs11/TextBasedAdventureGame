extern void executeLook(const char *noun);
extern void executeGo(const char *noun);
