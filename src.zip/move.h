extern const char *moveObject(OBJECT *obj, OBJECT *to);
