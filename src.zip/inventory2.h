extern int executeGetFrom(void);
extern int executePutIn(void);
extern int executeAskFrom(void);
extern int executeGiveTo(void);
