
const char *cannotEat(void);
const char *cannotDrink(void);

extern int executeEat(void);
extern int executeDrink(void);
