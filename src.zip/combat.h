extern int executeFight(void);

extern const char *cannotFight(void);
