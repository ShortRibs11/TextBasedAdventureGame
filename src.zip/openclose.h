extern int executeOpen(void);
extern int executeClose(void);
extern int executeLock(void);
extern int executeUnlock(void);
